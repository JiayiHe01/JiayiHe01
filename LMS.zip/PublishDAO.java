package com.gcit.lms.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.gcit.lms.domain.Author;
import com.gcit.lms.domain.Book;
import com.gcit.lms.domain.Publisher;

public class PublishDAO extends BaseDAO{

	public void insertpublish(Publisher pub) throws ClassNotFoundException, SQLException{
		save("insert into tbl_publisher (publisherName) values (?)", new Object[] {pub.getPublisherName()});
	}
	
	public void delectpublish(Publisher pub) throws ClassNotFoundException, SQLException{
		save("delete from tbl_publisher where publisherID=?", new Object[] {pub.getPublisherId()});
	}
        
	public void deleteAll() throws ClassNotFoundException, SQLException{
		save("delete * from tbl_publisher", null);
	}
	
	public void updatebook(Publisher pub) throws ClassNotFoundException, SQLException{
		save("update  tbl_author set bookID = ? where title = ?",
                        new Object[] {pub.getPublisherId(),pub.getPublisherName()});
	}
	
	public List<Author> readAll() throws ClassNotFoundException, SQLException{
		PreparedStatement pstmt = getConnection().prepareStatement("select * from tbl_author");
		List<Author> authors = new ArrayList<Author>();
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()){
			Author a = new Author();
			a.setAuthorId(rs.getInt("authorId"));
			a.setAuthorName(rs.getString("authorName"));
			authors.add(a);
		}
		return authors;
	}

	@Override
	public List<Publisher> extractData(ResultSet rs) throws SQLException {
		List<Publisher> pub = new ArrayList<Publisher>();
		while(rs.next()){
			Publisher a = new Publisher();
                        a.setPublisherName(rs.getString("pulisherName"));
			a.setPublisherAddress(rs.getString("publisherAddress"));
                        a.setPublisherPhone(rs.getString("publisherPhone"));
                        a.setPublisherId(rs.getInt("publisherId"));
			pub.add(a);
		}
		return pub;
	}
}
