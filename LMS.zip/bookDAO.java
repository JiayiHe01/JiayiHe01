package com.gcit.lms.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.gcit.lms.domain.Author;
import com.gcit.lms.domain.Book;
import com.gcit.lms.domain.Genre;

public class bookDAO extends BaseDAO{

	public void insertbook(Book book) throws ClassNotFoundException, SQLException{
		save("insert into tbl_book (title) values (?)", new Object[] {book.getTitle()});
	}
	
	public void deletebook(Book book) throws ClassNotFoundException, SQLException{
		save("delete from tbl_book where bookID=?", new Object[] {book.getBookId()});
	}
        
	public void deleteAll() throws ClassNotFoundException, SQLException{
		save("delete * from tbl_book", null);
	}
	
	public void updatebook(Book book) throws ClassNotFoundException, SQLException{
		save("update  tbl_author set bookID = ? where title = ?",
                        new Object[] {book.getBookId(),book.getTitle()});
	}
	
	public List<Book> readAll() throws ClassNotFoundException, SQLException{
		PreparedStatement pstmt = getConnection().prepareStatement("select * from tbl_author");
		List<Book> book = new ArrayList<Book>();
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()){
			Book a = new Book();
			a.setPubID(rs.getInt("pubId"));
			a.setTitle(rs.getString("title"));
                         List<Author> books = (List<Author>) read("select * from tbl_author where authorId IN (select authorId from tbl_book_authors where bookId =  ?",new Object[]{rs.getInt("bookId")});
			  a.setAuthors(books);
			 List<Genre> g = (List<Genre>) read("select * from tbl_genere where genere_id IN (select genereId from tbl_book_generes where bookId =  ?",new Object[]{rs.getInt("bookId")});                        
			book.add(a);
		}
		return book;
	}

	@Override
	public List<Book> extractData(ResultSet rs) throws SQLException {
		List<Book> book = new ArrayList<Book>();
		while(rs.next()){
			Book a = new Book();
                        a.setBookId(rs.getInt("bookID"));
			a.setTitle(rs.getString("title"));
		        a.setPubID(rs.getInt("pubId"));
			book.add(a);
		}
		return book;
	}
}
