package com.gcit.lms.dao;

import com.gcit.lms.domain.Author;
import com.gcit.lms.domain.Book;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class JDBC {
	
	private static String driver= "com.mysql.jdbc.Driver";
	private static String url = "jdbc:mysql://localhost/library";
	private static String username = "root";
	private static String pass = "baobei0723";

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
//		Class.forName(driver);
//		Connection conn = DriverManager.getConnection(url, username, pass);
//		String query = "select * from tbl_author";
		//Statement stmt = conn.createStatement();
		
		AuthorDAO aut = new AuthorDAO();
                Author author = new Author();
                author.setAuthorName("kk");
                aut.insertAuthor(author);
                
                List<Author> autho = new ArrayList<>();
                
                autho = aut.readAll();
                for(int i = 0;i<autho.size();i++)
                {
                    System.out.println(autho.get(i).getAuthorName());
                }
                
                bookDAO boo = new bookDAO();
                Book book = new Book();
                book.setTitle("ifif");
                book.setPubID(90);
                boo.insertbook(book);          
                //System.out.print(boo.extractData(rs));
//		Scanner scan = new Scanner(System.in);
//		System.out.println("Enter a new Author: ");
//		String authorName = scan.nextLine();
//		String query1 = "insert into tbl_book (title) values('"+authorName+"')";
//		String query2 = "insert into tbl_author (authorName) values('"+authorName+"')";
//		String query3 = "select * from tbl_author where authorName like '"+authorName+"'";
//		String query4 = "select * from tbl_author where authorId = ?";
//		//stmt.executeUpdate(query);
//		PreparedStatement pstmt = conn.prepareStatement(query1);
//		//pstmt.setString(1, authorName);
//		//pstmt.setInt(1, 200);
//		pstmt.executeUpdate();
//                ResultSet rs = pstmt.executeQuery(query);
//                
//                
//		
//		while(rs.next()){
//			System.out.println("Author Name: " +rs.getString("authorName"));
//			System.out.println("Author ID: "+rs.getInt("authorId"));
//			System.out.println("-----------------------");
		}
}

