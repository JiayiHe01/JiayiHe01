package com.gcit.lms.dao;

import com.gcit.lms.domain.Book;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.gcit.lms.domain.Genre;

public class GenreDAO extends BaseDAO{

	public void insertGenre(Genre genre) throws ClassNotFoundException, SQLException{
		save("insert into tbl_genre (genre_name) values (?)", new Object[] {genre.getGenre_name()});
	}
	
	public void deleteAuthor(Genre genre) throws ClassNotFoundException, SQLException{
		save("delete from tbl_genre where genre_id=?", new Object[] {genre.getGenre_id()});
	}
	
	public void deleteAll() throws ClassNotFoundException, SQLException{
		save("delete * from tbl_genre", null);
	}
	
	public void updateGenre(Genre genre) throws ClassNotFoundException, SQLException{
		save("update  tbl_genre set genre_name = ? where genre_id = ?", new Object[] {genre.getGenre_name(), genre.getGenre_id()});
	}
	
	public List<Genre> readAll() throws ClassNotFoundException, SQLException{
		PreparedStatement pstmt = getConnection().prepareStatement("select * from tbl_author");
		List<Genre> genre = new ArrayList<Genre>();
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()){
			Genre a = new Genre();
			a.setGenre_id(rs.getInt("genre_id"));
			a.setGenre_name(rs.getString("genre_name"));
                         List<Book> books = (List<Book>) read("select * from tbl_book where bookId IN (select bookId from tbl_book_genres where 'genre_id' =  ?",new Object[]{rs.getInt("genre_id")});
			genre.add(a);
		}
		return genre;
	}

	@Override
	public List<Genre> extractData(ResultSet rs) throws SQLException {
		List<Genre> genres = new ArrayList<Genre>();
		while(rs.next()){
			Genre a = new Genre();
			a.setGenre_id(rs.getInt("genres_id"));
			a.setGenre_name(rs.getString("genre_name"));
			
			genres.add(a);
		}
		return genres;
	}
}
