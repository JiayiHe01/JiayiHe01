package com.gcit.lms.dao;

import com.gcit.lms.domain.Author;
import com.gcit.lms.domain.Book;
import com.gcit.lms.service.AdministrativeService;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class JDBC {
	
//	private static String driver= "com.mysql.jdbc.Driver";
//	private static String url = "jdbc:mysql://localhost/library";
//	private static String username = "root";
//	private static String pass = "baobei0723";

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
                Author au = new Author();
                au.setAuthorName("hello");
                AdministrativeService ser = new AdministrativeService();
                ser.addAuthor(au);
                List<Author> a = new ArrayList<>();
                a = ser.viewAuthors();
                 
                List<Book> b = new ArrayList<>();
                Book boo = new Book();
                boo.setTitle("title");
                b = ser.viewBook();
                
                System.out.println(b.get(0).getAuthors().size());
                for(int i = 0; i <b.get(0).getAuthors().size();i++)
                System.out.print(b.get(0).getAuthors().get(i).getAuthorName());
                
//		Class.forName(driver);
//		Connection conn = DriverManager.getConnection(url, username, pass);
//		String query = "select * from tbl_author";
//		//Statement stmt = conn.createStatement();
//		query = "select * from tbl_author where authorName like ?";
//		PreparedStatement pstmt = conn.prepareStatement(query);
//		
//		Scanner scan = new Scanner(System.in);
//		System.out.println("Enter a new Author: ");
//		String authorName = scan.nextLine();
//		
//		query = "insert into tbl_author (authorName) values('"+authorName+"')";
//		query = "select * from tbl_author where authorName like '"+authorName+"'";
//		query = "select * from tbl_author where authorId = ?";
//		//stmt.executeUpdate(query);
//		
//		//pstmt.setString(1, authorName);
//		pstmt.setInt(1, 200);
//		ResultSet rs = ser.viewAuthors();
//	
//		while(rs.next()){
//			System.out.println("Author Name: " +rs.getString("authorName"));
//			System.out.println("Author ID: "+rs.getInt("authorId"));
//			System.out.println("-----------------------");
//		}
//                System.out.print(a);
	}
}
