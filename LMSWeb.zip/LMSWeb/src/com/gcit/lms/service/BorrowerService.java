package com.gcit.lms.service;

public class BorrowerService {

}
